﻿using UnityEngine;
using System.Collections;

public class OffsetScroller : MonoBehaviour
{

    public GameObject player;
    public float scrollSpeed;
    private Vector2 savedOffset;

    private string materialName;

    void Start()
    {
        materialName = "_MainTex";
        GetComponent<Renderer>().sharedMaterial.SetTextureOffset(materialName, new Vector2(0, 0));
        savedOffset = GetComponent<Renderer>().sharedMaterial.GetTextureOffset(materialName);
    }

    void Update()
    {
        Vector2 velocity = player.GetComponent<Rigidbody2D>().velocity;
        float speed = player.GetComponent<Rigidbody2D>().velocity.magnitude;        

        Vector2 offset = new Vector2(savedOffset.x + (velocity.x * ((speed / 10000) * scrollSpeed)), savedOffset.y + ((velocity.y * ((speed / 10000) * scrollSpeed))));
        GetComponent<Renderer>().sharedMaterial.SetTextureOffset(materialName, offset);

        savedOffset = GetComponent<Renderer>().sharedMaterial.GetTextureOffset(materialName);
    }

    void OnDisable()
    {
        GetComponent<Renderer>().sharedMaterial.SetTextureOffset(materialName, savedOffset);
    }
}