﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateController : MonoBehaviour {

    public float rotateSpeed;
    public GameObject player;
    public GameObject planet;
    public GameObject destinationPad;

    // Update is called once per frame
    void FixedUpdate () {
        var rotate = new Vector3(0.0f, 0.0f, rotateSpeed);
        transform.Rotate(rotate);
        
        // To stop the player sliding all over the place when landing on a rotating planet,
        // if they touch the planet or landing pad (if there is one), they are parented to the planet, and share its rotation
        if (player.GetComponent<Rigidbody2D>().IsTouching(planet.GetComponent<Collider2D>())
            || (destinationPad != null && player.GetComponent<Rigidbody2D>().IsTouching(destinationPad.GetComponent<Collider2D>()))
            )
        {
            player.transform.parent = transform;
        }
	}
}
