﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class DestinationArrowController : MonoBehaviour {

    private GameObject player;
    private GameObject destination;
    public Text distanceCounter;
    private int distanceMultiplier = 3;

    // Use this for initialization
    void Start () {
        player = GameObject.FindGameObjectWithTag("Player");
        destination = GameObject.FindGameObjectWithTag("DestinationPlatform");
    }
	
	// Update is called once per frame
	void Update () {
        Vector3 diff = destination.GetComponent<Transform>().position - player.transform.position;
        diff.Normalize();

        float rot_z = Mathf.Atan2(diff.y, diff.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.Euler(0f, 0f, rot_z - 90);

        var distance = Vector3.Distance(player.GetComponent<Rigidbody2D>().position, destination.GetComponent<Rigidbody2D>().position);
        var distCalc = Mathf.Round((distance - 3) * distanceMultiplier);
        var dist = (distCalc > 0 ? distCalc : 0);
        distanceCounter.text = dist + "m";
    }
}
