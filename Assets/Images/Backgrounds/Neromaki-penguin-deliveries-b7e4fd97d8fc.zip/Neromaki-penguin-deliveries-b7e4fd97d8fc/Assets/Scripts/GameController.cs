﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine;

public class GameController : MonoBehaviour
{
    // Planets and gravity
    public float maxGravityAffectDistance = 4.0f;
    public float maxGravity = 15.0f;
    GameObject[] planets;

    // Player, origin and destination objects
    public GameObject player;
    private GameObject origin;
    private GameObject destination;

    // UI bits
    public GameObject winUI;
    public Text winText;
    public Text parTimeText;
    public Text yourTimeText;
    public string[] winnerText;
    public Text timeText;

    // Timer and level-specific stuff
    public float parTime = 10.0f;

    private float timer = 0.0f;
    private bool timerStart = false;

    private AudioSource[] objectAudio;


    void Start()
    {

        winUI.SetActive(false);
        winText.text = winnerText[Random.Range(0, winnerText.Length)].ToString();
        parTimeText.text = parTime.ToString("F2") + "s";

        origin = GameObject.FindGameObjectWithTag("OriginPlatform");
        destination = GameObject.FindGameObjectWithTag("DestinationPlatform");
        planets = GameObject.FindGameObjectsWithTag("Planet");

        objectAudio = GetComponents<AudioSource>();

        GameObject[] backgrounds = GameObject.FindGameObjectsWithTag("Background");

        foreach(GameObject background in backgrounds)
        {
            if (background.GetComponent<Renderer>())
            {
                background.GetComponent<Renderer>().sharedMaterial.SetTextureOffset("_MainTex", new Vector2(0, 0));
            }
        }


        //audio[1].Play();
    }

    private void Update()
    {
        if (!timerStart && !player.GetComponent<Rigidbody2D>().IsTouching(origin.GetComponent<BoxCollider2D>()) && !player.GetComponent<Rigidbody2D>().IsTouching(destination.GetComponent<BoxCollider2D>()))
        {
            timerStart = true;
        }

        if(timerStart)
        {
            timer += Time.deltaTime;
            timeText.text = timer.ToString("F2") + "s";
        }

        if (player.GetComponent<Rigidbody2D>().IsTouching(destination.GetComponent<BoxCollider2D>()) && player.GetComponent<Rigidbody2D>().IsSleeping() && timerStart)
        {
            Win();
        }

        if(Input.GetAxis("Restart") > 0.0f)
        {
            ReplayLevel();
        }

        if (Input.GetAxis("Quit") > 0.0f || Input.GetAxis("Q") > 0.0f)
        {
            Quit();
        }
    }

    void FixedUpdate()
    {
        foreach (GameObject planet in planets)
        {
            float distance = Vector3.Distance(planet.transform.position, player.transform.position);

            if (distance <= maxGravityAffectDistance && !player.GetComponent<Rigidbody2D>().IsTouching(planet.GetComponent<Collider2D>()))
            {
                Vector3 gravitationalForce = planet.transform.position - player.transform.position;
                player.GetComponent<Rigidbody2D>().AddForce(gravitationalForce.normalized * (1.0f - distance / maxGravityAffectDistance) * maxGravity);
            }
        }
    }

    public void Win()
    {
        timerStart = false;
        yourTimeText.text = timer.ToString("F2") + "s";
        winUI.SetActive(true);
        objectAudio[0].Play();
    }

    public void NextLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void LoadLevel(string scene)
    {
        SceneManager.LoadScene(scene);
    }

    public void ReplayLevel()
    {
        timer = 0.0f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void Quit()
    {
        Application.Quit();
    }
}
