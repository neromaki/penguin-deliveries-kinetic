﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float turnSpeed = 5.0f;
    public float thrust = 20.0f;
    public float maxSpeed = 10.0f;

    private Animator animator;
    private GameObject engine;
    private AudioSource[] playerAudio;

    private bool engineOn = false;
    private bool bonking = false;
    private float bonkTimer;
    public int bonkTimeout;

    public float bonkVelocity = 5.0f;

    void Start()
    {
        engine = GameObject.FindGameObjectWithTag("Engine");
        animator = engine.GetComponent<Animator>();
        playerAudio = GetComponents<AudioSource>();

        bonkTimer = bonkTimeout;
    }

    void Update()
    {
        if (bonking && bonkTimer > 0)
        {
            bonkTimer -= Time.deltaTime;
        }
        else if (bonking && bonkTimer <= 0)
        {
            bonking = false;
            bonkTimer = bonkTimeout;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        float velocity = GetComponent<Rigidbody2D>().velocity.magnitude;

        if (!bonking && velocity >= bonkVelocity)
        {
            //audio[1].Play();
            bonking = true;

        }

    }

    void FixedUpdate()
    {        
        // Rotation
        var v2 = new Vector3(0.0f, 0.0f, Input.GetAxis("Horizontal"));
        transform.Rotate(-v2 * 100 * turnSpeed * Time.deltaTime);

        // Moving up
        if (Input.GetKey("up"))
        {
            GetComponent<Rigidbody2D>().AddForce(transform.up * thrust);
            animator.SetTrigger("EngineOn");

            if (!engineOn)
            {
                engineOn = true;

                playerAudio[0].Play();
            }

            transform.parent = null;
        }
        else
        {
            
            animator.SetTrigger("EngineOff");
            if (engineOn)
            {
                engineOn = false;
                playerAudio[0].Stop();
            }
        }

        //Debug.Log("player speed: " + GetComponent<Rigidbody2D>().velocity.magnitude);
        if (GetComponent<Rigidbody2D>().velocity.magnitude > maxSpeed)
        {
            //Debug.Log("exceeding max speed!");
            //GetComponent<Rigidbody2D>().AddForce(transform.up * (GetComponent<Rigidbody2D>().velocity.magnitude - (GetComponent<Rigidbody2D>().velocity.magnitude * 2)));
        }
    }
}